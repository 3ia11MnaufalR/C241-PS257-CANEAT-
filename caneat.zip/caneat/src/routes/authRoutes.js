const express = require('express');
const router = express.Router();
const authController = require('../controller/authController');

// Mount the googleLogin function on /auth/google route
router.get('/google', authController.googleLogin);

// Mount the googleCallback function on /auth/google/callback route
router.get('/google/callback', authController.googleCallback);

module.exports = router;
