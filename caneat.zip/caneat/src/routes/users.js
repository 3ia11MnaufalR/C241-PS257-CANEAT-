const express = require('express');
const router = express.Router();
const userController = require('../controller/users');

// Create
router.post('/users', userController.createUser);

// Read
router.get('/users', userController.getUsers);
router.get('/users/:id', userController.getUserById);

// Update
router.put('/users/:id', userController.updateUser);

// Delete
router.delete('/users/:id', userController.deleteUser);

module.exports = router;
