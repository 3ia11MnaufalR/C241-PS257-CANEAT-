const dotenv = require('dotenv');
const express = require('express');
const bodyParser = require('body-parser');
const usersRoutes = require('./routes/users');
const authRoutes = require('./routes/authRoutes');
const middlewareLogRequest = require('./middleware/logs');

dotenv.config();

const app = express();

app.use(express.json());
app.use(middlewareLogRequest);
app.use(bodyParser.json());

app.use('/api', usersRoutes); // Mount usersRoutes on /api

// Mount authRoutes on /auth
app.use('/auth', authRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
