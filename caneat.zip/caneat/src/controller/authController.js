// authController.js
const { google } = require('googleapis');
const dbPool = require('../config/database');
const dotenv = require('dotenv');
dotenv.config();


const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    'http://localhost:4000/auth/google/callback'
);

const scopes = [
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile'
];

const authorizationUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: scopes,
    include_granted_scopes: true,
});

// Function to handle redirect to Google OAuth
const googleLogin = (req, res) => {
    res.redirect(authorizationUrl);
};

// Function to handle callback from Google OAuth
const googleCallback = async (req, res) => {
    const { code } = req.query;

    try {
        const { tokens } = await oauth2Client.getToken(code.toString());
        oauth2Client.setCredentials(tokens);

        const oauth2 = google.oauth2({
            auth: oauth2Client,
            version: 'v2'
        });

        const { data } = await oauth2.userinfo.get();

        if (!data.email || !data.name) {
            return res.json({
                error: 'Google user data not found'
            });
        }

        let connection;
        try {
            connection = await dbPool.getConnection();
            
            // Perform database operations here, for example:
            const [rows, fields] = await connection.execute('SELECT * FROM users WHERE email = ?', [data.email]);

            let user;

            if (rows.length === 0) {
                // If user not found, create new user
                const [insertedRow] = await connection.execute('INSERT INTO users (name, email, address) VALUES (?, ?, ?)', [data.name, data.email, "-"]);

                user = {
                    id: insertedRow.insertId,
                    name: data.name,
                    email: data.email,
                    address: "-"
                };
            } else {
                // If user found, fetch user information from the matching row
                user = rows[0];
            }

            return res.json({
                data: {
                    id: user.id,
                    name: user.name,
                    address: user.address
                }
            });
        } catch (error) {
            console.error('Error executing MySQL query:', error);
            return res.status(500).json({
                message: 'Internal Server Error'
            });
        } finally {
            if (connection) {
                connection.release();
            }
        }
    } catch (error) {
        console.error('Error in Google OAuth callback:', error);
        return res.status(500).json({
            message: 'Internal Server Error'
        });
    }
};

module.exports = {
    googleLogin,
    googleCallback
};
