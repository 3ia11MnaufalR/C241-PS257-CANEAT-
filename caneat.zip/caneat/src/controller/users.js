const dbPool = require('../config/database');

// Create
exports.createUser = async (req, res) => {
    const { nama, email, address } = req.body;
    try {
        const [result] = await dbPool.query(
            'INSERT INTO users (nama, email, address) VALUES (?, ?, ?)',
            [nama, email, address]
        );
        res.status(201).json({ id: result.insertId, nama, email, address });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Read
exports.getUsers = async (req, res) => {
    try {
        const [results] = await dbPool.query('SELECT * FROM users');
        res.status(200).json(results);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getUserById = async (req, res) => {
    const { id } = req.params;
    try {
        const [results] = await dbPool.query('SELECT * FROM users WHERE id = ?', [id]);
        if (results.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.status(200).json(results[0]);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Update
exports.updateUser = async (req, res) => {
    const { id } = req.params;
    const { nama, email, address } = req.body;
    try {
        const [result] = await dbPool.query(
            'UPDATE users SET nama = ?, email = ?, address = ? WHERE id = ?',
            [nama, email, address, id]
        );
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.status(200).json({ id, nama, email, address });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Delete
exports.deleteUser = async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await dbPool.query('DELETE FROM users WHERE id = ?', [id]);
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
